const express = require("express");
const mongoose = require("mongoose");
const app = express();

app.use(express.json());

mongoose.connect('mongodb://localhost/restfultaskapi_db', {useNewUrlParser: true});

const TaskSchema = new mongoose.Schema({
    title: {type: String,},
    description: {type: String},
    completed: {type: Boolean}},
    {timestamps:true}
    );

const Task = mongoose.model('Task', TaskSchema); 

app.get('/tasks', (req, res)=>{
    console.log("GET /tasks");
    Task.find()
    .then(alltasks=> {res.json(alltasks); console.log('all tasks', alltasks);})
    .catch(err => res.json(err));
})


app.get('/tasks/:id', (req, res)=>{
    console.log('GET /tasks/:id');
    const {id} = req.params;
    Task.findOne({_id: id})
    .then(gettask => {res.json(gettask); console.log('task is: ', gettask);})
    .catch(err => res.json(err));
})

app.post('/tasks', (req, res)=>{
    console.log('POST /tasks');
    console.log('req body', req.body);
    const task = new Task(req.body);
    task.save()        
    .then(newtask => {
        console.log('newtask', newtask); 
        res.json({message: newtask.title + ' has been added', task: newtask});
    })
    .catch(err => res.json(err));
})

app.put('/tasks/:id', (req, res)=> {
    console.log('PUT /tasks/:id');
    const {id} = req.params;
    console.log("The task id requested is:", id);
    console.log('req body', req.body);
    Task.findById({_id: id})
    .then(updatetask => {
        updatetask.title = req.body.title;
        updatetask.description = req.body.description;
        updatetask.completed = req.body.completed;
        return updatetask.save();
    })
    .then(updatedtask => {console.log('updated task', updatedtask); res.json({message: 'Task has been updated', task: updatedtask});})
    .catch(err => res.json(err))
})

app.delete('/tasks/:id', (req, res)=>{
    console.log('DELETE /tasks/:id');
    const {id} = req.params;
    console.log("The task id requested is:", id);
    Task.findByIdAndDelete({_id: id})
    .then(deletedTask=> {res.json(deletedTask.title + ' has been removed'); console.log('deleted task 39', deletedTask );})
    .catch(err => res.json(err));
})

app.listen(8000, function () {console.log('listening on port 8000')});